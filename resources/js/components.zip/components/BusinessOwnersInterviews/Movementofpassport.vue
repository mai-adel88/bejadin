<template>
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">تسجيل استلام جواز السفر </h3>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-md-4">
                    <label for="branch">الفرع</label>
                    <select class="form-control" v-model="branch" name="branch_id" id="branch" @change="branche()">
                        <option disabled value="">select one</option>
                        <option v-for="branch in branches" :key="branch.id" :value="branch.id">{{branch.name_ar}}</option>
                    </select>
                    <template v-for="error in errors.branche_id">
                        <div :key="error" v-if="errors.branche_id != ''" class="alert alert-danger" style="margin:10px 0" role="alert">{{error}}</div>
                    </template>
                </div>
                <div class="col-md-4">
                    <label for="date">التاريخ</label>
                    <input class="form-control" v-model="form.datepassport" type="date" name="" id="date">
                </div>
                <div class="col-md-4">
                    <label for="movementnumber">رقم الحركة</label>
                    <input class="form-control" v-model="form.move_number_passport" type="text" name="" id="movementnumber">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <label for="employer">المتعاقد - الباحث عن العمل</label>
                    <select2 class="form-control applicant" v-model="employer" name="applicanth_id" id="employer" v-on:input="getcompany()">
                        <option disabled value="">Select one</option>
                        <template v-for="applicant in applicants">
                            <option :key="applicant.id" :value="applicant.id">{{applicant.name_ar}}</option>
                        </template>
                    </select2>
                    <template v-for="error in errors.applicant_id">
                        <div :key="error" v-if="errors.applicant_id != ''" class="alert alert-danger" style="margin:10px 0" role="alert">{{error}}</div>
                    </template>
                </div>
                <div class="col-md-6">
                    <label for="company">اصحاب الاعمال</label>
                    <select2 class="form-control applicant" v-model="company" name="company_id" id="company" v-on:input="companyform()">
                        <option disabled value="">Select one</option>
                        <template v-for="company in companies">
                            <option :key="company.id" :value="company.id">{{company.name_ar}}</option>
                        </template>
                    </select2>
                    <template v-for="error in errors.company_id">
                        <div :key="error" v-if="errors.company_id != ''" class="alert alert-danger" style="margin:10px 0" role="alert">{{error}}</div>
                    </template>
                </div>
            </div>
            <hr>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th scope="col" class="col-md-6">نوع المستند</th>
                        <th scope="col" class="col-md-6">التسجيل</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">قيمة العقد</th>
                        <td><input class="form-control" @keyup="total(),spinnercheck()"  :class="{'is_valid' : form.contract_value == '' && alert == true}" v-model.number="form.contract_value" value="0" type="number" name="contract_value" id=""></td>
                    </tr>
                    <tr>
                        <th scope="row">قيمة الاتعاب</th>
                        <td><input class="form-control" @keyup="total()" v-model.number="form.value_of_fees" value="0" type="number" name="value_of_fees" id=""></td>
                    </tr>
                    <tr>
                        <th scope="row">المسدد</th>
                        <td><input class="form-control" @keyup="total()" v-model.number="form.payee" value="0" type="number" name="payee" id=""></td>
                    </tr>
                    <tr>
                        <th scope="row">الباقى</th>
                        <td><span class="total">{{rest}}</span></td>
                    </tr>
                    <tr>
                        <th scope="row">تاريخ التسليم</th>
                        <td><input class="form-control" @change="spinnercheck()" :class="{'is_valid' : form.delivery_date == '' && alert == true}" v-model="form.delivery_date" value="" type="date" name="delivery_date" id=""></td>
                    </tr>
                </tbody>
            </table>
            <hr>
            <button :disabled="spinner" class="btn btn-primary" @click="senddata()">
                <i class="fa fa-spinner fa-pulse" v-if="spinner"></i>
                <span v-else>{{save}}</span>
                <!-- {{spinner == true ? <i class="fas fa-spinner fa-pulse"></i> : 'حفظ'}} -->
            </button>
        </div>
        <!-- /.box-body -->
    </div>

</template>

<script>
import axios from 'axios';
import Select2 from '../Select2.vue';
export default {
    data(){
        return{
            applicants:[],
            employer:'',
            companies:[],
            company:'',
            branches:[],
            branch:'',
            errors:[],
            rest:0,
            alert:false,
            spinner:false,
            save:'حفظ',
            form:{
                branche_id:'',
                applicant_id:'',
                company_id:'',
                datepassport:'',
                move_number_passport:'',
                contract_value:0,
                value_of_fees:0,
                payee:0,
                delivery_date:'',
            }
        }
    },
    methods:{
        branche:function(){
            this.form.branche_id = this.branch
        },
        companyform:function(){
            this.form.company_id = this.company
            axios.get('api/admin/datarecoverypassport/'+ this.employer +'/'+ this.company).then((response)=>{
                if (response.data[0] != '') {
                    this.form = response.data[0]
                    this.save = 'تعديل'
                    this.total()
                }else{
                    this.form.datepassport = ''
                    this.form.move_number_passport = ''
                    this.form.contract_value = 0
                    this.form.value_of_fees = 0
                    this.form.payee = 0
                    this.form.rest = 0
                    this.form.delivery_date = ''
                    this.save = 'حفظ'
                    this.alert = false
                    this.total()
                }
            })
        },
        getapplicants:function(){
            axios.get('api/admin/applicantmovement').then((response)=>{
                this.applicants = response.data[0]
            }).catch((error)=>{
                console.log(error)
            })
        },
        getcompany:function(){
            this.company = ''
            this.companies = []
            this.form.applicant_id = this.employer
            axios.get('api/admin/companiesmovement/'+ this.employer).then((response)=>{
                this.companies = response.data[0]
            }).catch((error)=>{
                console.log(error)
            })
        },
        getbranches:function(){
            axios.get('api/admin/branches').then((response)=>{
                this.branches = response.data[0]
            }).catch((error)=>{
                console.log(error)
            })
        },
        senddata:function(){
            this.spinner = true
                if(this.employer == '' || this.branche == '' || this.company == '') {
                    axios.post('api/admin/datapassportpost',this.form).catch(({ response })=>{
                        this.errors = response.data.errors
                         this.spinner = false
                    })
                }else{
                    if (this.form.contract_value == 0 || this.form.delivery_date == '' || this.form.contract_value == '') {
                        this.alert = true
                        this.errors = []
                    }else{
                        axios.post('api/admin/datapassportpost',this.form).then((response)=>{

                        }).finally(()=>{
                            this.spinner = false
                            Swal.fire({
                                type: 'success',
                                title: 'تم الحفظ بنجاح'
                            })
                        })
                    }
                }

        },
        total:function(){
            this.rest = (Number(this.form.contract_value) + Number(this.form.value_of_fees)) - Number(this.form.payee)
        },
        spinnercheck:function(){
            if (this.form.contract_value != 0 && this.form.delivery_date != '' || this.form.contract_value != '' && this.form.delivery_date != '') {
                this.spinner = false
            }
        }
    },
    computed:{

    },
    created(){
        this.getapplicants()
        this.getbranches()
    },
    mounted() {
        $(".applicant").select2();
    },
    components:{
        'select2':Select2
    },
}
</script>

<style scoped>
.table tbody tr .alert{
    padding: 10px !important;
}
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
.alert input{
    padding: 10px
}
.total{
    display: flex;
    justify-content: center;
    font-size: 40px;
}
.is_valid{
    border: 1px solid red;
    box-shadow: 0 0 3px 0px red;
}
</style>

